setTimeout(function() {
    $('.about-info-inner').typed({
      strings: [
        "<span>Hi, I am Sajad Al-Shammari</span> I attend at HTL Wien West"
      ],
      typeSpeed: 7,
      contentType: 'html'
    });
  }, 100);